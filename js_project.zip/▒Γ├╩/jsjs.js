let arr = [1,2,3,4,5]
let obj = {
  'x':1,
  'y':2
}
let str = "abc"

console.log(arr.toString())
console.log(obj.toString())
console.log(str.toString())



/*
var obj = {
  'x':1,
  'y':2
}//연관배열(map, table), Dictionary

var arr={
  0:1
  1:2
  2:3
}


for (var variable in arr) {
  if (arr.hasOwnProperty(variable)) {
    console.log(variable)
  }
}

for (var variable in obj) {
  if (obj.hasOwnProperty(variable)) {
    console.log(variable)
    obj[variable]
  }
}

for (variable of arr) {
  console.log(variable)
}
*/
